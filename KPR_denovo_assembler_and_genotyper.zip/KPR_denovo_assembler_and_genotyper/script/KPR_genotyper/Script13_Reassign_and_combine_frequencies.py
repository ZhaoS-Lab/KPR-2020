#!/usr/bin/python

import sys

if __name__ == '__main__':
	X50_reads = sys.argv[1]
	norm_reads = sys.argv[2]
	X50_geno = sys.argv[3]
	norm_geno = sys.argv[4]
	with open(X50_reads,'r') as f:
		X50_reads = f.read()
	with open(norm_reads,'r') as f:
		norm_reads = f.read()
	with open(X50_geno,'r') as f:
		X50_geno = f.read()
	with open(norm_geno,'r') as f:
		norm_geno = f.read()
	# output files
	out = open('Merged_genotyping_result.txt','w')
	X50_reads = X50_reads.split('>')[1:]
	norm_reads = norm_reads.split('>')[1:]
	X50_geno = X50_geno.split('\n')[:-1]
	norm_geno = norm_geno.split('\n')[:-1]
	# data processing
	X50_count = len(X50_reads)
	norm_count = len(norm_reads)
	X50_ratio = float(X50_count) / (X50_count + norm_count)
	norm_ratio = float(norm_count) / (X50_count + norm_count)
	if X50_geno == []:
		X50_ratio = 0.0
		norm_ratio = 1.0
	for i in range(len(norm_geno)):
		contig = norm_geno[i].split('\t')[1]
		percentage = float(norm_geno[i].split('\t')[2])
		new_contig = 'Norm' + contig
		new_percentage = percentage * norm_ratio
		string = norm_geno[i].split('\t')[0] + '\t' + new_contig + '\t' + str(new_percentage) + '\t' + '\t'.join(norm_geno[i].split('\t')[3:]) + '\n'
		out.write(string)
	for i in range(len(X50_geno)):
        	contig = X50_geno[i].split('\t')[1]
        	percentage = float(X50_geno[i].split('\t')[2])
        	new_contig = '50X' + contig
        	new_percentage = percentage * X50_ratio
        	string = X50_geno[i].split('\t')[0] + '\t' + new_contig + '\t' + str(new_percentage) + '\t' + '\t'.join(X50_geno[i].split('\t')[3:]) + '\n'
        	out.write(string)
	out.close()

