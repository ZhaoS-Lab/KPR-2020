#!/usr/bin/python

import sys
import re

###########################################
def build_read_pairwise_linkage_dic(read_pairwise_linkage):
	dic = {}
	for i in range(len(read_pairwise_linkage)):
		key = read_pairwise_linkage[i].split('\t')[0]
		value = int(read_pairwise_linkage[i].split('\t')[1])
		dic[key] = value
	return dic

def remove_values_from_list(the_list, val):
	return [value for value in the_list if value != val]

def linkage_dic(contig_linkage):
	dic = {}
	for i in range(len(contig_linkage)):
		contig = contig_linkage[i].split('\n')[0]
		linkage_lst = contig_linkage[i].split('\n')[1].split('\t') # sorted
		linkage_lst = remove_values_from_list(linkage_lst,'')
		dic[contig] = linkage_lst
	return dic

def atoi(text):
	return int(text) if text.isdigit() else text

def natural_keys(text):
	return [ atoi(c) for c in re.split(r'(\d+)', text) ]

def find_most_diverse_pair(linkage_lst,pairwise_linkage_dic,pos_linkage_dic,exclude_pair_lst):
        # this function returns index pairs with highest coverage # this pair should have reads spaning it
        result = []
        diversity = 0
        count = 0
	idx = []
        if len(linkage_lst) >= 2:
                length = len(linkage_lst[0])
                for i in range(length-1):
                        for j in range(i+1,length):
                                site_lst = []
				pair = str(re.findall(r'\d+',linkage_lst[0][i])[0]) + '_' + str(re.findall(r'\d+',linkage_lst[0][j])[0])
				if pair not in exclude_pair_lst:
					flag = True
                             		for k in range(len(linkage_lst)):
                                        	rec = linkage_lst[k]
						pair2 = linkage_lst[k][i] + '_' + linkage_lst[k][j]
						if pair2 not in pairwise_linkage_dic.keys():
							flag = False
                                        	tmp = [rec[i],rec[j]]
                                        	site_lst.append(tmp)
                                	unique_site_lst = [list(x) for x in set(tuple(x) for x in site_lst)]
                                	if len(unique_site_lst) > diversity and flag:
                                        	pair = str(re.findall(r'\d+',linkage_lst[0][i])[0]) + '_' + str(re.findall(r'\d+',linkage_lst[0][j])[0])
                                        	count = pos_linkage_dic[pair]
                                       		result = [re.findall(r'\d+',linkage_lst[0][i])[0],re.findall(r'\d+',linkage_lst[0][j])[0]]
						idx = [i,j]
                                        	diversity = len(unique_site_lst)
                                	elif len(unique_site_lst) == diversity and flag:
                                        	pair = str(re.findall(r'\d+',linkage_lst[0][i])[0]) + '_' + str(re.findall(r'\d+',linkage_lst[0][j])[0])
                                        	if pos_linkage_dic[pair] > count:
                                                	count = pos_linkage_dic[pair]
                                                	result = [re.findall(r'\d+',linkage_lst[0][i])[0],re.findall(r'\d+',linkage_lst[0][j])[0]]
							idx = [i,j]
        return result,idx

def assign_frequency(linkage_lst,pairwise_linkage_dic,pos_linkage_dic,total_percentage,exclude_pair_lst,result_dic):
        most_diverse_pair,idx = find_most_diverse_pair(linkage_lst,pairwise_linkage_dic,pos_linkage_dic,exclude_pair_lst)
        pos1 = int(most_diverse_pair[0])
        pos2 = int(most_diverse_pair[1])
	print pos1
	print pos2
	print '###'
	idx1 = int(idx[0])
	idx2 = int(idx[1])
        freq_count = {}
	linkage_dic = {}
	percentage_count = {}
        if len(linkage_lst) >= 2:
                for i in range(len(linkage_lst)):
                        linkage = linkage_lst[i]
                        pair = linkage[idx1] + '_' + linkage[idx2]
			pos_pair = str(re.findall(r'\d+',linkage[idx1])[0]) + '_' + str(re.findall(r'\d+',linkage[idx2])[0])
			#exclude_pair_lst.append(pos_pair)
			exclude_pair_lst = [pos_pair]
			if pair in pairwise_linkage_dic.keys():
				freq = pairwise_linkage_dic[pair]
			else:
				freq = 0.0
			#freq = pos_linkage_dic[pos_pair]
			if pair not in freq_count.keys():
				freq_count[pair] = freq
				linkage_dic[pair] = [linkage]
			else:
				linkage_dic[pair].append(linkage)
		# convert freq to percentage
		pairs = linkage_dic.keys()
		total = sum(freq_count.values())
		for i in range(len(pairs)):
			pair = pairs[i]
			percentage = float(freq_count[pair]) * total_percentage / total
			percentage_count[pair] = percentage
		# analyze unique and dup pairs
		pairs = linkage_dic.keys()
		for i in range(len(pairs)):
			pair = pairs[i]
			if len(linkage_dic[pair]) == 1:
				print pair + '\t' + str(percentage_count[pair])
				total_percentage -= percentage_count[pair]
		for i in range(len(pairs)):
                        pair = pairs[i]
                        if len(linkage_dic[pair]) == 1:
                                link = '_'.join(linkage_dic[pair][0])
                                result_dic[link] = percentage_count[pair]
                                print link
                                print result_dic[link]
			else:
				new_linkage_lst = linkage_dic[pair]
				total_percentage = percentage_count[pair]
				print 'total_percentage:' + str(total_percentage)
				result_dic = assign_frequency(new_linkage_lst,pairwise_linkage_dic,pos_linkage_dic,total_percentage,exclude_pair_lst,result_dic)
	return (result_dic)
		
#########################################
if __name__ == '__main__':
	contig_linkage = sys.argv[1]
	read_pairwise_linkage = sys.argv[2]
	pos_linkage = sys.argv[3]
	with open(contig_linkage,'r') as f:
        	contig_linkage = f.read()
	with open(read_pairwise_linkage,'r') as f:
        	read_pairwise_linkage = f.read()
	with open(pos_linkage,'r') as f:
        	pos_linkage = f.read()
	contig_linkage = contig_linkage.split('>')[1:]
	read_pairwise_linkage = read_pairwise_linkage.split('\n')[:-1]
	pos_linkage = pos_linkage.split('\n')[:-1]
	# output files
	out = open('Correct_contigs_percentageScores.txt','w')
	# data processing
	pairwise_linkage_dic = build_read_pairwise_linkage_dic(read_pairwise_linkage)
	pos_linkage_dic = build_read_pairwise_linkage_dic(pos_linkage)
	contig_linkage_dic = linkage_dic(contig_linkage)
	linkage_lst = contig_linkage_dic.values()
	total_percentage = 1
	result_dic = {}
	exclude_pair_lst = []
	result_dic = assign_frequency(linkage_lst,pairwise_linkage_dic,pos_linkage_dic,total_percentage,exclude_pair_lst,result_dic)
	linkages = result_dic.keys()
	contigs = contig_linkage_dic.keys()
	contigs.sort(key=natural_keys)
	for i in range(len(linkages)):
		linkage = linkages[i].split('_')
		percentage = result_dic[linkages[i]]
		for j in range(len(contigs)):
			contig = contigs[j]
			linkage2 = contig_linkage_dic[contig]
			if linkage == linkage2:
				string = '>' + contig + '\n' + str(percentage) + '\n' + '\t'.join(linkage) + '\n'
				out.write(string)
	out.close()

