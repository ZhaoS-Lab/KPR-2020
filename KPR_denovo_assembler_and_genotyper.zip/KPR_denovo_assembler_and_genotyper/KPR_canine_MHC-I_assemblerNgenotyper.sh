#PBS -S /bin/bash
#PBS -q batch
#PBS -N KPR
#PBS -l nodes=1:ppn=4
#PBS -l walltime=72:00:00
#PBS -l mem=75gb

##################################################################
####################### Sample Info ##############################
##################################################################

script=''     # path to the KPR scripts
data=''       # path to the RNA-seq paired end fastq files
result=''     # path to the output directory
ref=''        # path to the KPR reference

fastq1=''     # RNA-seq fastq file 1
fastq2=''     # RNA-seq fastq file 2

K=50          # K-mer length
N=30000       # The number of assembly runs

# load modules
module load SAMtools/1.9-foss-2016b
module load Trimmomatic/0.36-Java-1.8.0_144
module load BWA/0.7.17-foss-2016b
module load SRA-Toolkit/2.9.1-centos_linux64
module load Clustal-Omega/1.2.4-foss-2016b


##################################################################
######################## Execution ###############################
##################################################################

script_assembler=$script'/KPR_assembler'
script_genotyper=$script'/KPR_genotyper'
result_tmp=$result'/execution'

mkdir $result
mkdir $result_tmp
cd $result_tmp

# Trimmomatics trimming
time java -jar /usr/local/apps/eb/Trimmomatic/0.36-Java-1.8.0_144/trimmomatic-0.36.jar PE -threads 4 \
$data/$fastq1 $data/$fastq2 \
sample_lane1_forward_paired.fq.gz sample_lane1_forward_unpaired.fq.gz \
sample_lane1_reverse_paired.fq.gz sample_lane1_reverse_unpaired.fq.gz \
ILLUMINACLIP:TruSeq3-PE.fa:2:30:10 LEADING:3 TRAILING:3 SLIDINGWINDOW:4:15 MINLEN:36

# DLA-I read extraction
time bwa aln $ref/DLA_Nucleotide_DB_GenBank_AllExons.fa sample_lane1_forward_paired.fq.gz > sample_lane1_forward_paired.sai
time bwa aln $ref/DLA_Nucleotide_DB_GenBank_AllExons.fa sample_lane1_reverse_paired.fq.gz > sample_lane1_reverse_paired.sai

time bwa sampe $ref/DLA_Nucleotide_DB_GenBank_AllExons.fa \
sample_lane1_forward_paired.sai \
sample_lane1_reverse_paired.sai \
sample_lane1_forward_paired.fq.gz \
sample_lane1_reverse_paired.fq.gz \
> sample_DLAdb.sam

samtools view -bS sample_DLAdb.sam > sample_DLAdb.bam
samtools sort sample_DLAdb.bam -o sample_DLAdb-sorted.bam
samtools index sample_DLAdb-sorted.bam

samtools view sample_DLAdb-sorted.bam | grep -v '^@' | awk '$2%16 == 3 && $3 != "*" && $6 !~ /S/ && $6 !~ /H/ {print $0}' > sample_BWA_reads.sam

gawk '(and(16, $2))' sample_BWA_reads.sam > DLA_reverseStrandReads.sam
gawk '(! and(16,$2))' sample_BWA_reads.sam > DLA_forwardStrandReads.sam

cat DLA_reverseStrandReads.sam | awk '$3 ~/DLA-88/ && $4 <= 445 {print $0}' > DLA_Exon2_reverseStrandReads.sam
cat DLA_forwardStrandReads.sam | awk '$3 ~/DLA-88/ && $4 <= 445 {print $0}' > DLA_Exon2_forwardStrandReads.sam
cat DLA_reverseStrandReads.sam | awk '$3 ~/DLA-12/ && $4 <= 436 {print $0}' >> DLA_Exon2_reverseStrandReads.sam
cat DLA_forwardStrandReads.sam | awk '$3 ~/DLA-12/ && $4 <= 436 {print $0}' >> DLA_Exon2_forwardStrandReads.sam
cat DLA_reverseStrandReads.sam | awk '$3 ~/DLA-64/ && $4 <= 445 {print $0}' >> DLA_Exon2_reverseStrandReads.sam
cat DLA_forwardStrandReads.sam | awk '$3 ~/DLA-64/ && $4 <= 445 {print $0}' >> DLA_Exon2_forwardStrandReads.sam

cat DLA_reverseStrandReads.sam | awk '$3 ~/DLA-88/ && $4 <= 725 {print $0}' > DLA_Exon2-3_reverseStrandReads.sam
cat DLA_forwardStrandReads.sam | awk '$3 ~/DLA-88/ && $4 <= 725 {print $0}' > DLA_Exon2-3_forwardStrandReads.sam
cat DLA_reverseStrandReads.sam | awk '$3 ~/DLA-12/ && $4 <= 716 {print $0}' >> DLA_Exon2-3_reverseStrandReads.sam
cat DLA_forwardStrandReads.sam | awk '$3 ~/DLA-12/ && $4 <= 716 {print $0}' >> DLA_Exon2-3_forwardStrandReads.sam
cat DLA_reverseStrandReads.sam | awk '$3 ~/DLA-64/ && $4 <= 725 {print $0}' >> DLA_Exon2-3_reverseStrandReads.sam
cat DLA_forwardStrandReads.sam | awk '$3 ~/DLA-64/ && $4 <= 725 {print $0}' >> DLA_Exon2-3_forwardStrandReads.sam

cat DLA_reverseStrandReads.sam | awk '$3 ~/DLA-88/ && $4 >= 246 && $4 <= 725 {print $0}' > DLA_Exon3_reverseStrandReads.sam
cat DLA_forwardStrandReads.sam | awk '$3 ~/DLA-88/ && $4 >= 246 && $4 <= 725 {print $0}' > DLA_Exon3_forwardStrandReads.sam
cat DLA_reverseStrandReads.sam | awk '$3 ~/DLA-12/ && $4 >= 237 && $4 <= 716 {print $0}' >> DLA_Exon3_reverseStrandReads.sam
cat DLA_forwardStrandReads.sam | awk '$3 ~/DLA-12/ && $4 >= 237 && $4 <= 716 {print $0}' >> DLA_Exon3_forwardStrandReads.sam
cat DLA_reverseStrandReads.sam | awk '$3 ~/DLA-64/ && $4 >= 246 && $4 <= 725 {print $0}' >> DLA_Exon3_reverseStrandReads.sam
cat DLA_forwardStrandReads.sam | awk '$3 ~/DLA-64/ && $4 >= 246 && $4 <= 725 {print $0}' >> DLA_Exon3_forwardStrandReads.sam

python $script_assembler/Sam_file_Quality_control.py DLA_Exon2_reverseStrandReads.sam 30
python $script_assembler/Sam_file_Quality_control.py DLA_Exon2_forwardStrandReads.sam 30
python $script_assembler/Sam_file_Quality_control.py DLA_Exon2-3_reverseStrandReads.sam 30
python $script_assembler/Sam_file_Quality_control.py DLA_Exon2-3_forwardStrandReads.sam 30
python $script_assembler/Sam_file_Quality_control.py DLA_Exon3_reverseStrandReads.sam 30
python $script_assembler/Sam_file_Quality_control.py DLA_Exon3_forwardStrandReads.sam 30

for i in DLA_Exon*.sam_QualityFiltered; do awk '{OFS="\t"; print ">"$1"\n"$10}' $i > "${i/%.sam_QualityFiltered/.fa}"; done

python $script_assembler/Get_Pairwise_reads.py DLA_Exon2_forwardStrandReads.fa DLA_Exon2_reverseStrandReads.fa
python $script_assembler/Get_Pairwise_reads.py DLA_Exon2-3_forwardStrandReads.fa DLA_Exon2-3_reverseStrandReads.fa
python $script_assembler/Get_Pairwise_reads.py DLA_Exon3_forwardStrandReads.fa DLA_Exon3_reverseStrandReads.fa

######################## Assembly #######################################

mkdir $result_tmp/Test4
cd $result_tmp

## 100bp
# DLA-88 1-73;74-345;346-625
# DLA-12 1-64;65-336;337-616
# DLA-64 1-73;74-345;346-625

### Forwd ###
python $script_assembler/Kmer_assembly4_V6.py DLA_Exon2_forwardStrandReads.fa-pair DLA_Exon2_reverseStrandReads.fa-pair $K $N 3 > Test4/'Kmer_Exon2_contigs-'$K'mer_'$N'.txt'
python $script_assembler/Kmer_assembly4_V6.py DLA_Exon2-3_forwardStrandReads.fa-pair DLA_Exon2-3_reverseStrandReads.fa-pair $K $N 3 > Test4/'Kmer_Exon2-3_contigs-'$K'mer_'$N'.txt'
python $script_assembler/Kmer_assembly4_V6.py DLA_Exon3_forwardStrandReads.fa-pair DLA_Exon3_reverseStrandReads.fa-pair $K $N 3 > Test4/'Kmer_Exon3_contigs-'$K'mer_'$N'.txt'

cd $result_tmp/Test4
mv 'Kmer_Exon2_contigs-'$K'mer_'$N'.txt' 'Kmer_Exon2_contigs-'$K'mer_'$N'.txt_merged'
mv 'Kmer_Exon2-3_contigs-'$K'mer_'$N'.txt' 'Kmer_Exon2-3_contigs-'$K'mer_'$N'.txt_merged'
mv 'Kmer_Exon3_contigs-'$K'mer_'$N'.txt' 'Kmer_Exon3_contigs-'$K'mer_'$N'.txt_merged'

python $script_assembler/Step3_Compare_for_rev_V2.py 'Kmer_Exon2_contigs-'$K'mer_'$N'.txt_merged' $K
python $script_assembler/Step3_Compare_for_rev_V2.py 'Kmer_Exon2-3_contigs-'$K'mer_'$N'.txt_merged' $K
python $script_assembler/Step3_Compare_for_rev_V2.py 'Kmer_Exon3_contigs-'$K'mer_'$N'.txt_merged' $K

### Rev ###

cd $result_tmp
python $script_assembler/Kmer_assembly4_V6.py DLA_Exon2_reverseStrandReads.fa-pair DLA_Exon2_forwardStrandReads.fa-pair $K $N 3 > Test4/'Kmer_Exon2_contigs-'$K'mer_'$N'-REV.txt'
python $script_assembler/Kmer_assembly4_V6.py DLA_Exon2-3_reverseStrandReads.fa-pair DLA_Exon2-3_forwardStrandReads.fa-pair $K $N 3 > Test4/'Kmer_Exon2-3_contigs-'$K'mer_'$N'-REV.txt'
python $script_assembler/Kmer_assembly4_V6.py DLA_Exon3_reverseStrandReads.fa-pair DLA_Exon3_forwardStrandReads.fa-pair $K $N 3 > Test4/'Kmer_Exon3_contigs-'$K'mer_'$N'-REV.txt'

cd $result_tmp/Test4
mv 'Kmer_Exon2_contigs-'$K'mer_'$N'-REV.txt' 'Kmer_Exon2_contigs-'$K'mer_'$N'-REV.txt_merged'
mv 'Kmer_Exon2-3_contigs-'$K'mer_'$N'-REV.txt' 'Kmer_Exon2-3_contigs-'$K'mer_'$N'-REV.txt_merged'
mv 'Kmer_Exon3_contigs-'$K'mer_'$N'-REV.txt' 'Kmer_Exon3_contigs-'$K'mer_'$N'-REV.txt_merged'

python $script_assembler/Step3_Compare_for_rev_V2.py 'Kmer_Exon2_contigs-'$K'mer_'$N'-REV.txt_merged' $K
python $script_assembler/Step3_Compare_for_rev_V2.py 'Kmer_Exon2-3_contigs-'$K'mer_'$N'-REV.txt_merged' $K
python $script_assembler/Step3_Compare_for_rev_V2.py 'Kmer_Exon3_contigs-'$K'mer_'$N'-REV.txt_merged' $K

assembly_merge=$result_tmp'/Test4/Merge2'
mkdir $assembly_merge
cd $assembly_merge

cat $result_tmp/Test4/*merged-Match > sample_contigs.fa # Merge all contigs
python $script_genotyper/Script0.5_merge_and_rename_contigs.py sample_contigs.fa 5 trim # Contigs dedup and trimming

rm -r tmp
cat sample_contigs.fa_merged_and_renamed $ref/DLA_Nucleotide_DB_AllExons.fa > tmp # contig classification (DLA-88*Norm DLA-88*50X DLA-12 DLA-64)

clustalo --force -i tmp -o sample-assembly.clustalO \
 --full --distmat-out=distance_matrix.txt --percent-id
rm tmp

# classify norm and 50X contigs
python $script_genotyper/Analyze_ClustalO_DistMatrix.py distance_matrix.txt sample_contigs.fa_merged_and_renamed


# merge D88-NORM, D12 as Norm
cat DLA12_contigs.txt DLA88-norm_contigs.txt DLA64_contigs.txt > norm_contigs.txt


# BWA mapping and extract read pairs
bwa index -a is sample_contigs.fa_merged_and_renamed

python $script_genotyper/Script9_fasta_to_fastq.py $result_tmp/DLA_Exon2-3_forwardStrandReads.fa $result_tmp/DLA_Exon2-3_reverseStrandReads.fa E

time bwa aln sample_contigs.fa_merged_and_renamed $result_tmp/DLA_Exon2-3_forwardStrandReads.fq > DLA_Exon2-3_forwardStrandReads.sai
time bwa aln sample_contigs.fa_merged_and_renamed $result_tmp/DLA_Exon2-3_reverseStrandReads.fq > DLA_Exon2-3_reverseStrandReads.sai

time bwa sampe sample_contigs.fa_merged_and_renamed  \
DLA_Exon2-3_forwardStrandReads.sai \
DLA_Exon2-3_reverseStrandReads.sai \
$result_tmp/DLA_Exon2-3_forwardStrandReads.fq \
$result_tmp/DLA_Exon2-3_reverseStrandReads.fq \
> sample_contigs.sam

cat sample_contigs.sam | grep -v '^@' | awk '$2%16==3 && $3 != "*" && $6 !~ /HSDI/ {print $0}' | grep -w 'XM:i:0' > sample_contigs_BWA_reads.sam
gawk '(and(16, $2))' sample_contigs_BWA_reads.sam > sample_contigs_BWA_reverseStrandReads.sam
gawk '(! and(16,$2))' sample_contigs_BWA_reads.sam > sample_contigs_BWA_forwardStrandReads.sam

python $script_assembler/Get_Pairwise_reads_V2.py sample_contigs_BWA_forwardStrandReads.sam sample_contigs_BWA_reverseStrandReads.sam 

# individual alignment and completeness checking
rm -r tmp
mkdir tmp

python $script_genotyper/Script5.1_Divide_consensus_sequences.py \
sample_contigs.fa_merged_and_renamed \
$assembly_merge/tmp

cd $assembly_merge/tmp
for i in Align*
do
        cat $i $script_genotyper/Db_Exon23_Nuc_index_reference.fa > foo.fa
        clustalo --force -i foo.fa -o $i'.clustalO'
        rm foo.fa
        python $script_genotyper/Script10_Extract_nuc_from_clustalO2.py $i'.clustalO'
done

for i in Align_*.clustalO_Exon2N3
do
python $script_genotyper/Summerize_coverage.py $i >> complete_contigs.txt
done

while read line
do
python $script_genotyper/classify_contigs.py $line'.clustalO_Exon2N3'
done < complete_contigs.txt

# Adjust mapping positions
cd tmp
ls *_50XDLA | sed 's/_50XDLA//g' > 50XDLA_lst.txt

cd $assembly_merge
python $script_genotyper/Script11_Adjust_sam_positions.py sample_contigs_BWA_reverseStrandReads.sam-pair $assembly_merge/tmp/ tmp/50XDLA_lst.txt
python $script_genotyper/Script11_Adjust_sam_positions.py sample_contigs_BWA_forwardStrandReads.sam-pair $assembly_merge/tmp/ tmp/50XDLA_lst.txt








# analyze normal and 50X seperately
mkdir normDLA 50XDLA
cp norm_contigs.txt normDLA
cp DLA88-50X_contigs.txt 50XDLA

### normal DLA ###
cd $assembly_merge/normDLA

clustalo --force -i norm_contigs.txt -o sample-assembly.clustalO

# create reference consensus sequence and identify polymorphic sites
python $script_genotyper/Script1_ConsensusSeq_polymorphicSite_identification_ClustalO5.py sample-assembly.clustalO 0.75

# Align reference consensus with DLA database representative alleles
cat sample-assembly.clustalO_ConsensusSequence $script_genotyper/Db_index_reference.fa > foo.fa
clustalo --force -i foo.fa -o sample-assembly.clustalO_ConsensusSequence_index
rm foo.fa

# correct clustalO alignment
python $script_genotyper/Script1.5_Check_alignment_and_correct_ClustalO.py \
sample-assembly.clustalO_ConsensusSequence_index \
sample-assembly.clustalO_ConsensusSequence \
sample-assembly.clustalO

# create reference consensus sequence and identify polymorphic sites
python $script_genotyper/Script1_ConsensusSeq_polymorphicSite_identification_ClustalO5.py sample-assembly.clustalO_corrected 0.75

# Align reference consensus with DLA database representative alleles
cat sample-assembly.clustalO_corrected_ConsensusSequence $script_genotyper/Db_index_reference.fa > foo.fa

if [[ $(grep '>' foo.fa | wc -l) -eq 1 ]]
then
cp foo.fa sample-assembly.clustalO_corrected_ConsensusSequence_index
else
clustalo --force -i foo.fa -o sample-assembly.clustalO_corrected_ConsensusSequence_index
fi

rm foo.fa

python $script_genotyper/Script2_Identify_polymorphicSite_linkages_with_sam9.py \
$assembly_merge/sample_contigs_BWA_forwardStrandReads.sam-pair_adjusted \
$assembly_merge/sample_contigs_BWA_reverseStrandReads.sam-pair_adjusted \
sample-assembly.clustalO_corrected_ConsensusSequence_index \
sample-assembly.clustalO_PolymorphicSites \
sample-assembly.clustalO_corrected_ContigLinkages \
sample-assembly.clustalO_corrected_ContigGroupsAndOutliers \
50

python $script_genotyper/classify_contigs_completeness.py \
sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigLinkages \
$assembly_merge/sample_contigs.fa_merged_and_renamed \
$assembly_merge/tmp/complete_contigs.txt \
sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers

python $script_genotyper/Script3_Merge_contigs_and_generate_consensus3.py \
sample-assembly.clustalO_corrected \
sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete \
$assembly_merge/sample_contigs_BWA_forwardStrandReads.sam-pair_adjusted \
$assembly_merge/sample_contigs_BWA_reverseStrandReads.sam-pair_adjusted \
sample-assembly.clustalO_corrected_ConsensusSequence_index

python $script_genotyper/Script4_ConsensusSequenceExtension_withPairedReads4.py \
$assembly_merge/sample_contigs_BWA_forwardStrandReads.sam-pair_adjusted \
$assembly_merge/sample_contigs_BWA_reverseStrandReads.sam-pair_adjusted \
sample-assembly.clustalO_corrected_ConsensusSequence_index \
sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs \
sample-assembly.clustalO_corrected_ConsensusSequence_index_PolymorphicSites_Linkage \
20


########## genotyping ###########
# rename extended contigs
python $script_genotyper/Script3_Rename_extended_contigs.py \
sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads \
ExtendedAlign

# extract core exons from extended contigs
rm -r tmp
mkdir tmp

python $script_genotyper/Script5.1_Divide_consensus_sequences.py \
sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed \
tmp/
cd tmp/
for i in ExtendedAlign*
do
        cat $i $script_genotyper/Db_Exon23_Nuc_index_reference.fa > foo.fa
        clustalo --force -i foo.fa -o $i'.clustalO'
        rm foo.fa
        python $script_genotyper/Script10_Extract_nuc_from_clustalO2.py $i'.clustalO'
done

for i in ExtendedAlign_*.clustalO_Exon2N3
do
python $script_genotyper/Summerize_coverage.py $i >> complete_contigs.txt
done

while read line
do
python $script_genotyper/classify_contigs.py $line'.clustalO_Exon2N3'
done < complete_contigs.txt

# extension validation
cd $assembly_merge/normDLA

if [ -f *clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed ]
then
if [[ $(grep '>' *clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed | wc -l) -ge 2 ]]
then

mkdir $assembly_merge/normDLA/Extended_contigs_validation
cp *clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed $assembly_merge/normDLA/Extended_contigs_validation

# BWA mapping
cd $assembly_merge/normDLA/Extended_contigs_validation
bwa index -a is sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed

bwa aln sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed $result_tmp/DLA_Exon2-3_forwardStrandReads_QualityFiltered.fq > DLA_Exon2-3_forwardStrandReads_QualityFiltered.sai
bwa aln sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed $result_tmp/DLA_Exon2-3_reverseStrandReads_QualityFiltered.fq > DLA_Exon2-3_reverseStrandReads_QualityFiltered.sai

bwa sampe sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed \
DLA_Exon2-3_forwardStrandReads_QualityFiltered.sai \
DLA_Exon2-3_reverseStrandReads_QualityFiltered.sai \
$result_tmp/DLA_Exon2-3_forwardStrandReads_QualityFiltered.fq \
$result_tmp/DLA_Exon2-3_reverseStrandReads_QualityFiltered.fq \
> sample_contigs.sam

cat sample_contigs.sam | grep -v '^@' | awk '$2%16==3 && $3 != "*" && $6 !~ /HSDI/ {print $0}' | grep -w 'XM:i:0' > sample_contigs_BWA_reads.sam
gawk '(and(16, $2))' sample_contigs_BWA_reads.sam > sample_contigs_BWA_reverseStrandReads.sam
gawk '(! and(16,$2))' sample_contigs_BWA_reads.sam > sample_contigs_BWA_forwardStrandReads.sam

python $script_assembler/Get_Pairwise_reads_V2.py sample_contigs_BWA_forwardStrandReads.sam sample_contigs_BWA_reverseStrandReads.sam

# Adjust mapping positions
cd $assembly_merge/normDLA/tmp/
ls *_50XDLA | sed 's/_50XDLA//g' > 50XDLA_lst.txt

cd $assembly_merge/normDLA/Extended_contigs_validation
python $script_genotyper/Script11_Adjust_sam_positions.py sample_contigs_BWA_forwardStrandReads.sam-pair $assembly_merge/normDLA/tmp/ $assembly_merge/normDLA/tmp/50XDLA_lst.txt
python $script_genotyper/Script11_Adjust_sam_positions.py sample_contigs_BWA_reverseStrandReads.sam-pair $assembly_merge/normDLA/tmp/ $assembly_merge/normDLA/tmp/50XDLA_lst.txt

if [[ $(grep '>' sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed | wc -l) -eq 1 ]]
then
cp sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed sample-assembly.clustalO
else
clustalo --force -i sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed -o sample-assembly.clustalO
fi

# create reference consensus sequence and identify polymorphic sites
python $script_genotyper/Script1_ConsensusSeq_polymorphicSite_identification_ClustalO5.py sample-assembly.clustalO 0.75

# Align reference consensus with DLA database representative alleles
cat sample-assembly.clustalO_ConsensusSequence $script_genotyper/Db_index_reference.fa > foo.fa
clustalo --force -i foo.fa -o sample-assembly.clustalO_ConsensusSequence_index
rm foo.fa

# correct clustalO alignment
python $script_genotyper/Script1.5_Check_alignment_and_correct_ClustalO.py \
sample-assembly.clustalO_ConsensusSequence_index \
sample-assembly.clustalO_ConsensusSequence \
sample-assembly.clustalO

# create reference consensus sequence and identify polymorphic sites
python $script_genotyper/Script1_ConsensusSeq_polymorphicSite_identification_ClustalO5.py sample-assembly.clustalO_corrected 0.75

# Align reference consensus with DLA database representative alleles
cat sample-assembly.clustalO_corrected_ConsensusSequence $script_genotyper/Db_index_reference.fa > foo.fa
clustalo --force -i foo.fa -o sample-assembly.clustalO_corrected_ConsensusSequence_index
rm foo.fa

# check if all contigs are identical and no polymorphic site identified
if [ -s sample-assembly.clustalO_corrected_PolymorphicSites ]
then

python $script_genotyper/Script2_Identify_polymorphicSite_linkages_with_sam9.py \
sample_contigs_BWA_forwardStrandReads.sam-pair_adjusted \
sample_contigs_BWA_reverseStrandReads.sam-pair_adjusted \
sample-assembly.clustalO_corrected_ConsensusSequence_index \
sample-assembly.clustalO_PolymorphicSites \
sample-assembly.clustalO_corrected_ContigLinkages \
sample-assembly.clustalO_corrected_ContigGroupsAndOutliers \
50

python $script_genotyper/Script14_extract_sequences_from_correctedContigLinkages.py \
sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigLinkages \
sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed

cp sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed_validated $assembly_merge/normDLA
cd $assembly_merge/normDLA

else
cd $assembly_merge/normDLA
cp sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed \
sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed_validated

fi

else
cd $assembly_merge/normDLA
cp sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed \
sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed_validated

fi

else
cd $assembly_merge/normDLA
fi



# Extract exon 2 n 3
rm -r tmp
mkdir tmp

python $script_genotyper/Script5.1_Divide_consensus_sequences.py \
sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed_validated \
tmp/

cd tmp/
for i in ExtendedAlign*
do
        cat $i $script_genotyper/Db_Exon23_Nuc_index_reference.fa > foo.fa
        clustalo --force -i foo.fa -o $i'.clustalO'
        rm foo.fa
        python $script_genotyper/Script10_Extract_nuc_from_clustalO2.py $i'.clustalO'
done

for i in ExtendedAlign_*.clustalO_Exon2N3
do
python $script_genotyper/Summerize_coverage.py $i >> complete_contigs.txt
done

while read line
do
python $script_genotyper/classify_contigs.py $line'.clustalO_Exon2N3'
done < complete_contigs.txt


# merge all norm DLA complete contigs
mkdir $assembly_merge/normDLA/combined
cat $assembly_merge/tmp/*_normDLA *_normDLA > $assembly_merge/normDLA/combined/sample_normDLA_contigs.fa

cd $assembly_merge/normDLA/combined
python $script_genotyper/Script0.5_merge_and_rename_contigs.py sample_normDLA_contigs.fa 5 not

if [[ $(grep '>' sample_normDLA_contigs.fa_merged_and_renamed | wc -l) -eq 1 ]]
then
cp sample_normDLA_contigs.fa_merged_and_renamed sample-assembly.clustalO
else
clustalo --force -i sample_normDLA_contigs.fa_merged_and_renamed -o sample-assembly.clustalO
fi

python $script_genotyper/Script1_ConsensusSeq_polymorphicSite_identification_ClustalO5.py sample-assembly.clustalO 0.75

cat sample-assembly.clustalO_ConsensusSequence $script_genotyper/Db_index_reference.fa > foo.fa
clustalo --force -i foo.fa -o sample-assembly.clustalO_ConsensusSequence_index
rm foo.fa

python $script_genotyper/Script2_Identify_polymorphicSite_linkages_with_sam9.py \
$assembly_merge/sample_contigs_BWA_forwardStrandReads.sam-pair_adjusted \
$assembly_merge/sample_contigs_BWA_reverseStrandReads.sam-pair_adjusted \
sample-assembly.clustalO_ConsensusSequence_index \
sample-assembly.clustalO_PolymorphicSites \
sample-assembly.clustalO_ContigLinkages \
sample-assembly.clustalO_ContigGroupsAndOutliers \
50

python $script_genotyper/Script1_extract_sequences_basedOn_linkages2.py \
sample-assembly.clustalO_ConsensusSequence_index_correctedContigLinkages \
sample_normDLA_contigs.fa_merged_and_renamed \
Script2_polymorphicSites_nucleotide_frequencies

python $script_genotyper/Script5_Contig_translation4.py Correct_contigs.fa

cat Correct_contigs.fa_ProteinSeq $script_genotyper/Db_Exon23_index_reference.fa > foo.fa
clustalo --force -i foo.fa -o Correct_contigs.fa_ProteinSeq.clustalO
rm foo.fa

python $script_genotyper/Script6_Extract_3HVR_from_clustalO3.py Correct_contigs.fa_ProteinSeq.clustalO

python $script_genotyper/Script2_Genotyping_for_conplete_prot_seq2.py \
Correct_contigs.fa_ProteinSeq.clustalO_3HVR \
Correct_contigs.fa_ProteinSeq.clustalO_Exon2N3 \
$ref/DLA_881264_HVR_Prot-dedup.fasta \
$ref/DLA_881264_Exon23_Prot-dedup.fasta \
Correct_contigs_scores.txt \
sample

# Correct percentage
result_tmp=$assembly_merge'/normDLA/combined'

if [[ $(grep '>' $result_tmp/*_contigs.fa_merged_and_renamed | wc -l) -eq 1 ]]
then

cp $result_tmp/*_contigs.fa_merged_and_renamed  Correct_contigs.fa

python $script_genotyper/Script5_Contig_translation4.py Correct_contigs.fa
cat Correct_contigs.fa_ProteinSeq $script_genotyper/Db_Exon23_index_reference.fa > foo.fa
clustalo --force -i foo.fa -o Correct_contigs.fa_ProteinSeq.clustalO
rm foo.fa
python $script_genotyper/Script6_Extract_3HVR_from_clustalO3.py Correct_contigs.fa_ProteinSeq.clustalO
python $script_genotyper/Script2_Genotyping_for_conplete_prot_seq-noPolymorphicSite.py \
Correct_contigs.fa_ProteinSeq.clustalO_3HVR \
Correct_contigs.fa_ProteinSeq.clustalO_Exon2N3 \
$ref/DLA_881264_HVR_Prot-dedup.fasta \
$ref/DLA_881264_Exon23_Prot-dedup.fasta \
sample

else

python $script_genotyper/Script12_Correct_contig_percentage2.py \
sample-assembly.clustalO_ConsensusSequence_index_correctedContigLinkages \
Script2_pairwise_linkage \
Script2_pairwise_position_counts
python $script_genotyper/Script2_Genotyping_for_conplete_prot_seq2.py \
Correct_contigs.fa_ProteinSeq.clustalO_3HVR \
Correct_contigs.fa_ProteinSeq.clustalO_Exon2N3 \
$ref/DLA_881264_HVR_Prot-dedup.fasta \
$ref/DLA_881264_Exon23_Prot-dedup.fasta \
Correct_contigs_percentageScores.txt \
sample

fi



### 50X DLA ###
cd $assembly_merge/50XDLA

clustalo --force -i DLA88-50X_contigs.txt -o sample-assembly.clustalO

# create reference consensus sequence and identify polymorphic sites
python $script_genotyper/Script1_ConsensusSeq_polymorphicSite_identification_ClustalO5.py sample-assembly.clustalO 0.75

# Align reference consensus with DLA database representative alleles
cat sample-assembly.clustalO_ConsensusSequence $script_genotyper/Db_index_reference.fa > foo.fa
clustalo --force -i foo.fa -o sample-assembly.clustalO_ConsensusSequence_index
rm foo.fa

# correct clustalO alignment
python $script_genotyper/Script1.5_Check_alignment_and_correct_ClustalO.py \
sample-assembly.clustalO_ConsensusSequence_index \
sample-assembly.clustalO_ConsensusSequence \
sample-assembly.clustalO

# create reference consensus sequence and identify polymorphic sites
python $script_genotyper/Script1_ConsensusSeq_polymorphicSite_identification_ClustalO5.py sample-assembly.clustalO_corrected 0.75

# Align reference consensus with DLA database representative alleles
cat sample-assembly.clustalO_corrected_ConsensusSequence $script_genotyper/Db_index_reference.fa > foo.fa
clustalo --force -i foo.fa -o sample-assembly.clustalO_corrected_ConsensusSequence_index
rm foo.fa

python $script_genotyper/Script2_Identify_polymorphicSite_linkages_with_sam9.py \
$assembly_merge/sample_contigs_BWA_forwardStrandReads.sam-pair_adjusted \
$assembly_merge/sample_contigs_BWA_reverseStrandReads.sam-pair_adjusted \
sample-assembly.clustalO_corrected_ConsensusSequence_index \
sample-assembly.clustalO_PolymorphicSites \
sample-assembly.clustalO_corrected_ContigLinkages \
sample-assembly.clustalO_corrected_ContigGroupsAndOutliers \
50

python $script_genotyper/classify_contigs_completeness.py \
sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigLinkages \
$assembly_merge/sample_contigs.fa_merged_and_renamed \
$assembly_merge/tmp/complete_contigs.txt \
sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers

python $script_genotyper/Script3_Merge_contigs_and_generate_consensus3.py \
sample-assembly.clustalO_corrected \
sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete \
$assembly_merge/sample_contigs_BWA_forwardStrandReads.sam-pair_adjusted \
$assembly_merge/sample_contigs_BWA_reverseStrandReads.sam-pair_adjusted \
sample-assembly.clustalO_corrected_ConsensusSequence_index

python $script_genotyper/Script4_ConsensusSequenceExtension_withPairedReads4.py \
$assembly_merge/sample_contigs_BWA_forwardStrandReads.sam-pair_adjusted \
$assembly_merge/sample_contigs_BWA_reverseStrandReads.sam-pair_adjusted \
sample-assembly.clustalO_corrected_ConsensusSequence_index \
sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs \
sample-assembly.clustalO_corrected_ConsensusSequence_index_PolymorphicSites_Linkage \
20


########## genotyping ###########
# rename extended contigs
python $script_genotyper/Script3_Rename_extended_contigs.py \
sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads \
ExtendedAlign

# extract core exons from extended contigs
rm -r tmp
mkdir tmp

python $script_genotyper/Script5.1_Divide_consensus_sequences.py \
sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed \
tmp/

cd tmp/
for i in ExtendedAlign*
do
        cat $i $script_genotyper/Db_Exon23_Nuc_index_reference.fa > foo.fa
        clustalo --force -i foo.fa -o $i'.clustalO'
        rm foo.fa
        python $script_genotyper/Script10_Extract_nuc_from_clustalO2.py $i'.clustalO'
done

for i in ExtendedAlign_*.clustalO_Exon2N3
do
python $script_genotyper/Summerize_coverage.py $i >> complete_contigs.txt
done

while read line
do
python $script_genotyper/classify_contigs.py $line'.clustalO_Exon2N3'
done < complete_contigs.txt

# validate extended contigs
cd $assembly_merge/50XDLA

if [ -f *clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed ]
then
if [[ $(grep '>' *clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed | wc -l) -ge 2 ]]
then

mkdir $assembly_merge/50XDLA/Extended_contigs_validation
cp *clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed $assembly_merge/50XDLA/Extended_contigs_validation

# BWA mapping
cd $assembly_merge/50XDLA/Extended_contigs_validation
bwa index -a is sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed

bwa aln sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed $result_tmp/DLA_Exon2-3_forwardStrandReads_QualityFiltered.fq > DLA_Exon2-3_forwardStrandReads_QualityFiltered.sai
bwa aln sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed $result_tmp/DLA_Exon2-3_reverseStrandReads_QualityFiltered.fq > DLA_Exon2-3_reverseStrandReads_QualityFiltered.sai

bwa sampe sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed \
DLA_Exon2-3_forwardStrandReads_QualityFiltered.sai \
DLA_Exon2-3_reverseStrandReads_QualityFiltered.sai \
$result_tmp/DLA_Exon2-3_forwardStrandReads_QualityFiltered.fq \
$result_tmp/DLA_Exon2-3_reverseStrandReads_QualityFiltered.fq \
> sample_contigs.sam

cat sample_contigs.sam | grep -v '^@' | awk '$2%16==3 && $3 != "*" && $6 !~ /HSDI/ {print $0}' | grep -w 'XM:i:0' > sample_contigs_BWA_reads.sam
gawk '(and(16, $2))' sample_contigs_BWA_reads.sam > sample_contigs_BWA_reverseStrandReads.sam
gawk '(! and(16,$2))' sample_contigs_BWA_reads.sam > sample_contigs_BWA_forwardStrandReads.sam

python $script_assembler/Get_Pairwise_reads_V2.py sample_contigs_BWA_forwardStrandReads.sam sample_contigs_BWA_reverseStrandReads.sam

# Adjust mapping positions
cd $assembly_merge/50XDLA/tmp/
ls *_50XDLA | sed 's/_50XDLA//g' > 50XDLA_lst.txt

cd $assembly_merge/50XDLA/Extended_contigs_validation
python $script_genotyper/Script11_Adjust_sam_positions.py sample_contigs_BWA_forwardStrandReads.sam-pair $assembly_merge/50XDLA/tmp/ $assembly_merge/50XDLA/tmp/50XDLA_lst.txt
python $script_genotyper/Script11_Adjust_sam_positions.py sample_contigs_BWA_reverseStrandReads.sam-pair $assembly_merge/50XDLA/tmp/ $assembly_merge/50XDLA/tmp/50XDLA_lst.txt

if [[ $(grep '>' sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed | wc -l) -eq 1 ]]
then
cp sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed sample-assembly.clustalO
else
clustalo --force -i sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed -o sample-assembly.clustalO
fi

# create reference consensus sequence and identify polymorphic sites
python $script_genotyper/Script1_ConsensusSeq_polymorphicSite_identification_ClustalO5.py sample-assembly.clustalO 0.75

# Align reference consensus with DLA database representative alleles
cat sample-assembly.clustalO_ConsensusSequence $script_genotyper/Db_index_reference.fa > foo.fa
clustalo --force -i foo.fa -o sample-assembly.clustalO_ConsensusSequence_index
rm foo.fa

# correct clustalO alignment
python $script_genotyper/Script1.5_Check_alignment_and_correct_ClustalO.py \
sample-assembly.clustalO_ConsensusSequence_index \
sample-assembly.clustalO_ConsensusSequence \
sample-assembly.clustalO

# create reference consensus sequence and identify polymorphic sites
python $script_genotyper/Script1_ConsensusSeq_polymorphicSite_identification_ClustalO5.py sample-assembly.clustalO_corrected 0.75

# Align reference consensus with DLA database representative alleles
cat sample-assembly.clustalO_corrected_ConsensusSequence $script_genotyper/Db_index_reference.fa > foo.fa
clustalo --force -i foo.fa -o sample-assembly.clustalO_corrected_ConsensusSequence_index
rm foo.fa

# check if all contigs are identical and no polymorphic site identified
if [ -s sample-assembly.clustalO_corrected_PolymorphicSites ]
then

python $script_genotyper/Script2_Identify_polymorphicSite_linkages_with_sam9.py \
sample_contigs_BWA_forwardStrandReads.sam-pair_adjusted \
sample_contigs_BWA_reverseStrandReads.sam-pair_adjusted \
sample-assembly.clustalO_corrected_ConsensusSequence_index \
sample-assembly.clustalO_PolymorphicSites \
sample-assembly.clustalO_corrected_ContigLinkages \
sample-assembly.clustalO_corrected_ContigGroupsAndOutliers \
50

python $script_genotyper/Script14_extract_sequences_from_correctedContigLinkages.py \
sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigLinkages \
sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed

cp sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed_validated $assembly_merge/50XDLA
cd $assembly_merge/50XDLA

else
cd $assembly_merge/50XDLA
cp sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed \
sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed_validated

fi

else
cd $assembly_merge/50XDLA
cp sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed \
sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed_validated

fi

else
cd $assembly_merge/50XDLA
fi

# extract core exons from extended contigs
rm -r tmp
mkdir tmp

python $script_genotyper/Script5.1_Divide_consensus_sequences.py \
sample-assembly.clustalO_corrected_ConsensusSequence_index_correctedContigGroupsAndOutliers_incomplete_ConsensusSequencesWithUnusedContigs_extendedWithPairedReads_renamed_validated \
tmp/

cd tmp/
for i in ExtendedAlign*
do
        cat $i $script_genotyper/Db_Exon23_Nuc_index_reference.fa > foo.fa
        clustalo --force -i foo.fa -o $i'.clustalO'
        rm foo.fa
        python $script_genotyper/Script10_Extract_nuc_from_clustalO2.py $i'.clustalO'
done

for i in ExtendedAlign_*.clustalO_Exon2N3
do
python $script_genotyper/Summerize_coverage.py $i >> complete_contigs.txt
done

while read line
do
python $script_genotyper/classify_contigs.py $line'.clustalO_Exon2N3'
done < complete_contigs.txt

# merge all 50X complete contigs
mkdir $assembly_merge/50XDLA/combined
cat $assembly_merge/tmp/*_50XDLA *_50XDLA > $assembly_merge/50XDLA/combined/sample_50XDLA_contigs.fa

cd $assembly_merge/50XDLA/combined
python $script_genotyper/Script0.5_merge_and_rename_contigs.py sample_50XDLA_contigs.fa 5 not

if [[ $(grep '>' sample_50XDLA_contigs.fa_merged_and_renamed | wc -l) -eq 1 ]]
then
cp sample_50XDLA_contigs.fa_merged_and_renamed sample-assembly.clustalO
else
clustalo --force -i sample_50XDLA_contigs.fa_merged_and_renamed -o sample-assembly.clustalO
fi

python $script_genotyper/Script1_ConsensusSeq_polymorphicSite_identification_ClustalO5.py sample-assembly.clustalO 0.75

cat sample-assembly.clustalO_ConsensusSequence $script_genotyper/Db_index_reference.fa > foo.fa
clustalo --force -i foo.fa -o sample-assembly.clustalO_ConsensusSequence_index
rm foo.fa

python $script_genotyper/Script2_Identify_polymorphicSite_linkages_with_sam9.py \
$assembly_merge/sample_contigs_BWA_forwardStrandReads.sam-pair_adjusted \
$assembly_merge/sample_contigs_BWA_reverseStrandReads.sam-pair_adjusted \
sample-assembly.clustalO_ConsensusSequence_index \
sample-assembly.clustalO_PolymorphicSites \
sample-assembly.clustalO_ContigLinkages \
sample-assembly.clustalO_ContigGroupsAndOutliers \
50

python $script_genotyper/Script1_extract_sequences_basedOn_linkages2.py \
sample-assembly.clustalO_ConsensusSequence_index_correctedContigLinkages \
sample_50XDLA_contigs.fa_merged_and_renamed \
Script2_polymorphicSites_nucleotide_frequencies

python $script_genotyper/Script5_Contig_translation4.py Correct_contigs.fa

cat Correct_contigs.fa_ProteinSeq $script_genotyper/Db_Exon23_index_reference.fa > foo.fa
clustalo --force -i foo.fa -o Correct_contigs.fa_ProteinSeq.clustalO
rm foo.fa

python $script_genotyper/Script6_Extract_3HVR_from_clustalO3.py Correct_contigs.fa_ProteinSeq.clustalO

python $script_genotyper/Script2_Genotyping_for_conplete_prot_seq2.py \
Correct_contigs.fa_ProteinSeq.clustalO_3HVR \
Correct_contigs.fa_ProteinSeq.clustalO_Exon2N3 \
$ref/DLA_881264_HVR_Prot-dedup.fasta \
$ref/DLA_881264_Exon23_Prot-dedup.fasta \
Correct_contigs_scores.txt \
sample

# Correct percentage
result_tmp=$assembly_merge'/50XDLA/combined'

if [[ $(grep '>' $result_tmp/*_contigs.fa_merged_and_renamed | wc -l) -eq 1 ]]
then

cp $result_tmp/*_contigs.fa_merged_and_renamed  Correct_contigs.fa

python $script_genotyper/Script5_Contig_translation4.py Correct_contigs.fa
cat Correct_contigs.fa_ProteinSeq $script_genotyper/Db_Exon23_index_reference.fa > foo.fa
clustalo --force -i foo.fa -o Correct_contigs.fa_ProteinSeq.clustalO
rm foo.fa
python $script_genotyper/Script6_Extract_3HVR_from_clustalO3.py Correct_contigs.fa_ProteinSeq.clustalO
python $script_genotyper/Script2_Genotyping_for_conplete_prot_seq-noPolymorphicSite.py \
Correct_contigs.fa_ProteinSeq.clustalO_3HVR \
Correct_contigs.fa_ProteinSeq.clustalO_Exon2N3 \
$ref/DLA_881264_HVR_Prot-dedup.fasta \
$ref/DLA_881264_Exon23_Prot-dedup.fasta \
sample

else

python $script_genotyper/Script12_Correct_contig_percentage2.py \
sample-assembly.clustalO_ConsensusSequence_index_correctedContigLinkages \
Script2_pairwise_linkage \
Script2_pairwise_position_counts
python $script_genotyper/Script2_Genotyping_for_conplete_prot_seq2.py \
Correct_contigs.fa_ProteinSeq.clustalO_3HVR \
Correct_contigs.fa_ProteinSeq.clustalO_Exon2N3 \
$ref/DLA_881264_HVR_Prot-dedup.fasta \
$ref/DLA_881264_Exon23_Prot-dedup.fasta \
Correct_contigs_percentageScores.txt \
sample

fi


### merge DLA*normal and DLA*50X results
resultNorm=$assembly_merge'/normDLA/combined'
result50X=$assembly_merge'/50XDLA/combined'

cd $resultNorm
python $script_genotyper/Script2_Identify_polymorphicSite_linkages_with_sam9.py \
$assembly_merge/sample_contigs_BWA_forwardStrandReads.sam-pair_adjusted \
$assembly_merge/sample_contigs_BWA_reverseStrandReads.sam-pair_adjusted \
sample-assembly.clustalO_ConsensusSequence_index \
sample-assembly.clustalO_PolymorphicSites \
sample-assembly.clustalO_ContigLinkages \
sample-assembly.clustalO_ContigGroupsAndOutliers \
50

python $script_genotyper/Script13_Reassign_and_combine_frequencies.py \
Script2_50X_sequences \
Script2_norm_sequences \
$result50X/Genotyping_result.txt \
$resultNorm/Genotyping_result.txt

# gene assignment
if [ -f "Merged_genotyping_result.txt" ]
then

python $script_genotyper/Script15_genotypingResult_to_fasta.py Merged_genotyping_result.txt
cat Merged_genotyping_result.txt_newAllele.fa $ref/DLA_881264_Exon23_Prot-dedup.fasta > GeneAssignment.fa
clustalo --force -i GeneAssignment.fa -o GeneAssignment.clustalO --distmat-out=GeneAssignment.dist --percent-id --full
python $script_genotyper/Script16_combine_geneAssignment_info.py Merged_genotyping_result.txt GeneAssignment.dist_Summary
cp Merged_genotyping_result_withGeneAssignment.txt $result

else

echo "Genotyping failed" > $result/Merged_genotyping_result_withGeneAssignment.txt

fi

